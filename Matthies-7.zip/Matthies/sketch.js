var capture;
var ping;
var radius = 120;
var x = 0;
var speed = 1.0;
var direction = 1;
var sine;
var frequency = 400

function preload() {
  ping = loadSound("Ping.wav");
}

function setup() {
  createCanvas(480, 480);
  capture = createCapture();
  capture.hide();
  ellipseMode(RADIUS);
  x = width/2;
  sine = new p5.SinOsc();
  sine.start();
}

function draw() {
  background(0);
  var aspectRatio = capture.height/capture.width;
  var h = width * aspectRatio;
  image(capture, 0, 0, width, h);
  filter(GRAY);
  x += speed * direction;

  if ((x > width-radius) || (x < radius)) {

    direction = -direction;
    ping.play();

  }

  if (direction == 1) {
    arc(x, 200, radius, radius, 0.32, 4.76);
  } else {
    arc(x, 200, radius, radius, 2.67, 6.9);
  }
  var hertz = map(mouseX, 0, width, 20.0, 440.0);

  sine.freq(hertz);

  stroke(204);

  for (var x = 0; x < width; x++) {

    var angle = map(x, 0, width, 0, TWO_PI * hertz);

    var sinValue = sin(angle) * 120;

    line(x, 0, x, height/2 + sinValue);
    
  }
}
