
var img1;
var img2;
var img3;
var quote = "We have landed";
function preload() {

	img1 = loadImage("Flag.jpg");
	img2 = loadImage("landing.jpg");
	img3 = loadImage("clouds.png");

}

function setup () {

	createCanvas(480, 420);
	textFont("Helvetica");
	fill(0);
	stroke(255);

}

function draw () {
	background(204);
	image(img2, 0, 0);
	image(img1, 130, 0, 120, 60);
	image(img1,0, 0, mouseX * 2, mouseY * 2);
	image(img3, 0, mouseY * -1);
	textSize(16);
	text(quote, 25, 160, 200, 200);
}